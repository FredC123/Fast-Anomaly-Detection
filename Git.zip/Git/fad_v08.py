# -*- coding: utf-8 -*-

"""

Created on Tue Jul 12 10:19:20 2022
@author: Fred Coerver
This module takes a pandas frame as input, together with several hyperparameters. 
The pandas data frame must have a straight forward x and y column. Not morem Not less.
The output are two pandas dataframes.
1) table with statistal information of the input and whether a value x is identified as a spike or dip in the
dataset, based on the input parameters. The algorithm makes a window of datapoints from x - windowsizeleft to  x + windowsizeright
Linear regression is performed on this x-range with the give y-values. The regression value : y = slope*x+intercept
This window is iterated over the pandas frame and the regression values are put into the output table, along with the other statistical values
Input dataframe structure :
    1) pandas index as int
    2) x or DateTime value format %Y-%m-%d %H:%M:%S {working on an update that also accepts floats as x}. 
    Columnname must be "DateTime" if Timescale is true and must be next/right to the index
    3) y {float or int}. Columnn name is free. 
The dataframe can have more columns, but the script only analyzes 1 columns at a time.
So in in case you want to analyze more columns, you need to call the script for each column and slicing 
the dataframe in a way that the input frame complies to 1), 2) and 3)
Hyperparameters
ignore_startsamples = 5 (in case you want to omit starting rows from your calculation of the dataset. 
                         This parameter does not delete the rows! = default is 5. 
                         In case you increase the windowsizeleft, you might need to increase this value as well)
ignore_endsamples = 3 (in case you want to omit starting rows from your calculation of the dataset. 
                         This parameter does not delete the rows! 
                         In case you increase the windowsizeright, you might need to increase this value as well)
defaults:
P1inc=10 ()                  ---> In case the standard deviation of a regression window is P1inc-times higher as the previous std, 
                                  then this x value is marked as a spike
accuracy = 4                 ---> If a y-value exceeds the regressed value +- accuracy * std then this x-value is marked as spike
window_sizeleft = 3          ---> the regresssionwindow is #windowsizeleft x-values from the analyzed x-point and #windowsizeright x-values
                                  from the analyzed x-point. So suppose the algorythm calculates whether x[j] is a spike, 
                                  then the window x[j-windowsizeleft] until x[j+windowsizeright] is considerd as the window of x-points.
                                  From these x- an y-point the regression is calculated, and the regression value is compared with the actuel y-value
                                  
sd = 3                       ---> sd = slope detection
window_sizeright = 3         ---> amount of datapoint right from the x-value, which is subject for analyzing whether it is a spike/dip or not
ignoreendsamples = 3         ---> the Endresult output dataframe is capped with [ignorestartsamples:-ignoreendsamples] before returning to main
Timescale                    ---> If x-values are different from time then any string is valid, in case the x-values need to be in timeformat then this parameter is True.
OUTPUT:
1) Pandas dataframe with format columns:
    'DateTime', 'y-value', 'KPI_name', 'Regr_value', 'Value', 'Unixtime',
       'Std', 'spike', 'spikevalue', 'Slope', 'Intercept', 'Diff',
       'Regr_value_plus_std', 'Regr_value_min_std'
2) Pandas dataframe as 1) but then sorted and 'spike' ==1 or ==-1
"""


def Get_SandD(td_local,acc=6,
              windowsizeleft=3,
              windowsizeright=3,
              sp_name="KPI_name",
              P1=10,
              sd=3,
              ignorestartsamples=0,
              ignoreendsamples=0,
              absinc=1,
              step=5,
              mtv=0,
              meaninc=1,
              Timescale=True):
    
    import numpy as np
    from scipy import stats
    import datetime
    import time
    #import relevant modules just in case they are not loaded by main
    import pandas as pd
    import sys


    if not sys.warnoptions:
        import warnings
        warnings.simplefilter("ignore")
    
    def between(v1,v2,v3):
        if (v2>=v1 and v3>=v2):
            OKNOK= True
        else:
            OKNOK = False
        return OKNOK
    
    # Return the calculated regression value of the value x , which is the x-value in the mid of the window
    def myfunc(x):
        return slope * x + intercept

    #Convert Dateformat to Unixtime
    def DT2Unix(DT):
        unix = int(time.mktime(datetime.datetime.strptime( DT ,"%Y-%m-%d %H:%M:%S").timetuple()))
        return unix

    # Define the variables, which will be listed in the output pandas frame
    LS = len(td_local)

    if Timescale == True:
        xas = "Unixtime"
    else:
        xas = td_local.columns.to_list()[0]
           
    KPI = sp_name
    dfSin = td_local
    dfSin["KPI_name"] = sp_name
    dfSin["Regr_value"] = 0.0
    dfSin["Value"] = 0.0
    dfSin["Unixtime"] = 0
    dfSin["Std"] = 1.0
    dfSin["skew-y"] = 0.0
    dfSin["kurtosis-y"] = 0.0
    dfSin["spike"] = 99.0
    dfSin["spikevalue"] = 1.0
    dfSin["Slope"] = 1.0
    dfSin["Intercept"] = 1.0
    dfSin["Diff"] = 1.0
    dfSin["absinc"] = round(0.0,12)
    dfSin["Regr_value_plus_std"] = 1.0
    dfSin["Regr_value_min_std"] = 1.0
    dfSin["Reason"] = None

    # Fill the Unix time column with the unixtime, so that linear regression is possible of this part of the timetable
    j = 0
    while j<LS:
        if Timescale == True:
            dfSin["Unixtime"][j] = DT2Unix(str(dfSin["DateTime"][j]))
        dfSin["Value"][j] = dfSin[KPI][j]
        j += 1
    if mtv == 0: # minimum dynamic trigger value in case no mtv is defined in hyperparameter table and thus mtv=0
        mtv == dfSin["Value"].max()

    j=windowsizeleft + 1
    while j < LS - (windowsizeright + 1) :
        x = dfSin[xas][j - windowsizeleft:j].to_list() + dfSin[xas][j+1:j + windowsizeright+1].to_list() # regression point before and after RegrValue
        #print(f"x={x}")
        y = dfSin[KPI][j - windowsizeleft:j].to_list() + dfSin[KPI][j+1:j + windowsizeright+1].to_list()
        #print(f"y={y}")
        slope, intercept, r, p, std_err = stats.linregress(x, y)
        #print(f"slope/interept:{slope}/{intercept}")
        mymodel = list(map(myfunc, x))
        dfSin["Regr_value"][j] = round(slope * dfSin[xas][j] + intercept,12)
        dfSin["Diff"][j] = round(abs(dfSin[KPI][j] - dfSin["Regr_value"][j]),12)
        dfSin["Slope"][j] = round(float(slope),12)
        dfSin["Intercept"][j] = round(float(intercept),12)
        dfSin["Std"][j] = round((np.array(mymodel) - np.array(y)).std(),12)
        if dfSin["Diff"][j-1] !=0:
            output_par = (dfSin["Diff"][j]/dfSin["Regr_value"][j])/(dfSin["Diff"][j-1]/dfSin["Regr_value"][j-1])
        else:
            output_par = 0
        dfSin["absinc"][j] = round(output_par,12)
        dfSin["skew-y"][j] = stats.skew(y)
        dfSin["kurtosis-y"] = stats.kurtosis(y)
        dfSin["Regr_value_plus_std"][j] = dfSin["Regr_value"][j] + acc * dfSin["Std"][j]
        dfSin["Regr_value_min_std"][j] = dfSin["Regr_value"][j] - acc * dfSin["Std"][j]
        
        # If a previous sample indicates a spike, the next sample will be ignored.
        if (dfSin["spike"][j-1] >= 1 or dfSin["spike"][j-1] <= -1):
            dfSin["spike"][j] = 0
            dfSin["Reason"][j] = "0) set to 0 due to previous"

        # A step in mean value in the left window compared to the right window is a step up or down. Only the max differences are egligble
        elif (dfSin["Diff"][j] == dfSin["Diff"].max() or dfSin["Diff"][j] == dfSin["Diff"].min()) \
            and dfSin["Value"][j-windowsizeleft:j].mean() * step > dfSin["Value"][j:j+windowsizeright].mean() \
            and dfSin["Diff"][j] != 0 \
            and dfSin["Value"][j] != 0:
            dfSin["spike"][j] = 1
            dfSin["Reason"][j] = "7) step down of average regression value right window"
            
        # A step in mean value in the left window compared to the right window is a step up or down. Only the max differences are egligble
        elif (dfSin["Diff"][j] == dfSin["Diff"].max() or dfSin["Diff"][j] == dfSin["Diff"].min()) \
            and dfSin["Value"][j:j+windowsizeright].mean() * step > dfSin["Value"][j-windowsizeleft:j].mean() \
            and dfSin["Diff"][j] != 0 \
            and dfSin["Value"][j] != 0:
            #print(" - - ",dfSin["Value"][j:j+windowsizeright])
            dfSin["spike"][j] = 1
            dfSin["Reason"][j] = "8) step up of average regression value right window"
            
        # In case an actual value exceeds the modelvalue/regressionvalue + defined value of the standarddeviation AND the actual value is not between previous and future actual then
        # this actual is set as a spike
        elif dfSin[KPI][j] > dfSin["Regr_value"][j] + acc * dfSin["Std"][j] and not between(dfSin["Value"][j-1],
                                                                                          dfSin["Value"][j],
                                                                                          dfSin["Value"][j+1]):
            dfSin["spike"][j] = 1
            dfSin["Reason"][j] = "1) RegrValue + acc * Std above regression value"

        # In case an actual value is less than the modelvalue/regressionvalue - defined value of the standarddeviation AND the actual value is not between previous and future actual then
        # this actual is set as a spike
        elif dfSin[KPI][j] < dfSin["Regr_value"][j] - acc * dfSin["Std"][j] and not between(dfSin["Value"][j-1],
                                                                                          dfSin["Value"][j],
                                                                                          dfSin["Value"][j+1]):
            dfSin["spike"][j] = 1
            dfSin["Reason"][j] = "2) RegrValue - acc * Std below regression value"
            
        # In case an actual value is higher P1-times * the standard deviation than the first value of the regression-window AND the standard deviation of the start of the regressionwindow !=0
        # than trigger this as spike.
        elif dfSin["Std"][j] > P1 * dfSin["Std"][j-windowsizeleft] \
            and dfSin["Std"][j-windowsizeleft] != 0 \
            and dfSin["Value"][j] <= mtv:
            dfSin["spike"][j] =  (dfSin[KPI][j] - dfSin["Regr_value"][j])/dfSin["Diff"][j] # +1 or -1 P1
            dfSin["Reason"][j] = "3) Stdj  P1 times Stdj1"
            
        # If the regressed slope of the left point of the window times a defined value is still less that 
        # the regressed slope of the actual point than trigger a spike
        # and don't trigger a spike if the difference between the regressed value and the actual value is not significant. Next to this the actual value must not be 0
        elif abs(dfSin["Slope"][j-windowsizeleft-1]) * sd < abs(dfSin["Slope"][j]) \
            and abs(dfSin["Value"][j]) < dfSin["Diff"][j] \
            and dfSin["Value"][j] != 0 \
            and dfSin["Value"][j] <= mtv \
            and dfSin["Slope"][j-windowsizeleft-1] != 0:
            dfSin["spike"][j] = 1
            dfSin["Reason"][j] = "4) Slope increase from leftpoint to validationpoint"

        # If the regressed slope of the right point of the window times a defined value is still less that the regressed slope of the actual point than trigger a spike
        # and don't trigger a spike if the difference between the regressed value and the actual value is not significant. 
        # Next to this the actual value must not be 0
        elif abs(dfSin["Slope"][j+windowsizeright+1]) * sd < abs(dfSin["Slope"][j]) \
            and abs(dfSin["Value"][j]) < dfSin["Diff"][j] \
            and dfSin["Value"][j] != 0 \
            and dfSin["Value"][j] <= mtv \
            and dfSin["Slope"][j+windowsizeright+1] != 0:
            dfSin["spike"][j] = 1
            dfSin["Reason"][j] = "5) Slope decrease from validationpoint to rightpoint"
            
        # If the (deltaYx/Y)/(deltaYx-1/Yx-1) > hyperparameter then define spike:
        elif False and dfSin["absinc"][j] >= absinc and not between(dfSin["Value"][j-1],dfSin["Value"][j],dfSin["Value"][j+1]) \
            and dfSin["Value"][j] > dfSin["Value"].mean() \
            and dfSin["Value"][j] <= mtv:
            dfSin["spike"][j] = 1
            dfSin["Reason"][j] = "6) absolute increase (deltaYx/Yx)/(deltaYx-1/Yx-1)"
            
        # value is meaninc higher than mean value of total window.
        elif dfSin["Value"][j] > np.mean(y) * meaninc: #or dfSin["Value"][j] < np.mean(y) / meaninc and dfSin["Value"][j] <= mtv:
            dfSin["spike"][j] = 1
            dfSin["Reason"][j] = "9) value is meaninc higer than mean of total window"
        
        # In case none of the above elif-criteria is met, then keep the default value 0 as spikevalue, which is set in the beginning of the definition
        else:
            dfSin["spike"][j] = 0.0
            #print("pass")


            
        j += 1

    j = 1
    while j < LS:
        if dfSin["spike"][j] != 0:
            dfSin["spikevalue"][j] = dfSin["Regr_value"][j]
        else:
            dfSin["spikevalue"][j] = dfSin[KPI][j]
        # If the spike occurs during maintenance hour we ignore the spike
#        if dfSin["DateTime"][j].hour == 3:
#            dfSin["spike"][j] = 0
#            dfSin["Value"][j] = dfSin["Regr_value"]
#            dfSin["Reason"][j] = "0) set to 0 due to maintenance hour"        
        j += 1

    dfSin = dfSin[ignorestartsamples:len(dfSin)-ignoreendsamples]
    if Timescale == True:
        spikelist = pd.concat([dfSin[dfSin["spike"]>=1],dfSin[dfSin["spike"]<=-1]]).sort_values(by="DateTime")
    else:
        spikelist = pd.concat([dfSin[dfSin["spike"]>=1],dfSin[dfSin["spike"]<=-1]]).sort_values(by=xas)
        
    #dfSin = dfSin.fillna(0)

    #spikelist = spikelist[ignorestartsamples:-ignoreendsamples]
    
    return dfSin, spikelist